globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/1f7143bff62197d7.js",
      "static/chunks/turbopack-83dd2fce31b3809d.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/1f7143bff62197d7.js",
      "static/chunks/turbopack-f375f1dcc795c5ed.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b1cebaad23bcd57a.js",
    "static/chunks/9ab7b95c86946122.js",
    "static/chunks/b41cefb7ab3b80fa.js",
    "static/chunks/34af07c554206684.js",
    "static/chunks/turbopack-ff4c37a80b0933c0.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];