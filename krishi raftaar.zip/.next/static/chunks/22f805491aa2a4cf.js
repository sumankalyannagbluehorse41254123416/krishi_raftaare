__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/1f7143bff62197d7.js",
  "static/chunks/turbopack-f375f1dcc795c5ed.js"
])
